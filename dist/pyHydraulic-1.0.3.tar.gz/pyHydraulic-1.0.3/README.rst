Readme
======
pyHydraulic using PyQt5, built by Bruce Lee in Nanjing institute of technology
