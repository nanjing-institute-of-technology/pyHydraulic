# -*- coding: utf-8 -*-

__name__ = 'nodeeidtor_lib'
__author__ = 'lee'
__version__ = '1.0'
